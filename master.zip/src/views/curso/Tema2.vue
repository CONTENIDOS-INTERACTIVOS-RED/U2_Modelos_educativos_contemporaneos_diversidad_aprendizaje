<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'2. Diseño Universal de Aprendizaje (DUA)'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    .row.mb-5.align-items-center.justify-content-center 
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/18.png", data-aos="zoom-in")            
      .col-lg-8
        p(data-aos="fade-down") El Diseño Universal de Aprendizaje (DUA) es una estrategia metodológica innovadora, orientada a la transformación de los entornos educativos y de aprendizaje. Su enfoque supera los modelos tradicionales de planeación curricular, proponiendo una estructura que favorece la inclusión desde el diseño mismo del aprendizaje.
        .bg-color-2.p-4.j1(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 El DUA parte del reconocimiento de la diversidad del estudiantado y se propone crear escenarios educativos accesibles, equitativos y adaptables, que respondan a las múltiples formas de aprender, sentir y participar. Se basa en los avances de la neurociencia, las teorías del aprendizaje y las tecnologías aplicadas a la educación, lo cual permite ofrecer respuestas pedagógicas más efectivas y personalizadas.

    .bg-full-width-3.bg-fondo-1
      .px-4.px-md-5.pb-md-3
        .row.justify-content-center.mb-5      
          .col-lg-8
            SlyderF.text-center(columnas="col-12 col-lg-6")
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Accesibilidad
                p Los entornos, materiales y estrategias están diseñados desde el inicio para ser utilizables por todos los estudiantes.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Equidad
                p Todos los estudiantes, sin importar sus características individuales, acceden a las mismas oportunidades de aprendizaje.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Flexibilidad
                p Permite adaptar objetivos, métodos, evaluaciones y materiales, según las necesidades y estilos de aprendizaje.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Disponibilidad universal
                p Los recursos y estrategias deben estar disponibles para todos los estudiantes, no como ajustes posteriores, sino desde el diseño inicial.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Personalización del aprendizaje
                p Se enfoca en responder a las necesidades, oportunidades y capacidades particulares de cada estudiante.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Desarrollo del potencial 
                p Promueve el máximo desarrollo de las habilidades individuales, valorando los diferentes ritmos y trayectorias de aprendizaje.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/20.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Base científica y tecnológica
                p Se apoya en conocimientos de la neurociencia, teorías del aprendizaje y uso pedagógico de tecnologías para fundamentar su aplicabilidad.                                                                                               
          .col-lg-4
            figure
              img.img-a.img-t(src='@/assets/curso/temas/19.png', alt='')   

    .bg-full-width.bg-color-3.mb-5
      .px-4.px-md-5.py-4
        .row.align-items-center
          .col-lg
            p.mb-0 El DUA considera tres redes neuronales para proporcionar una enseñanza más inclusiva y adaptada a las diversas necesidades y estilos de aprendizaje de los estudiantes. 

    .titulo-figura.mb-4(data-aos="fade-up")
      h5 Figura 1. 
      span El DUA
    .bg-color-2.p-4.j1.mb-5(data-aos="fade-left")
      figure
        img.img-a.img-t(src='@/assets/curso/temas/27.svg', alt='')

    #t_2_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.1] Directrices para el DUA
  
    .row.mb-5 
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/28.png", data-aos="zoom-in")            
      .col-lg-8
        .bg-color-6.p-4.h-100.j1(data-aos="fade-left")
          p(data-aos="fade-down") Partiendo de la premisa de que los estudiantes aprenden mediante mediaciones pedagógicas en condiciones de motivación, con objetivos claros y precisos, el desarrollo de habilidades como la curiosidad es esencial. Los investigadores Hall, Meyer y Rose, identificaron tres redes neuronales claves que se activan durante los procesos de enseñanza y aprendizaje: la red de implicación, la red de representación y la red de acción y expresión (Alba, s.f.).

          p(data-aos="fade-down").mb-0 De forma teórica, a continuación se presenta un fundamento del Diseño Universal para el Aprendizaje (DUA) en contextos educativos, resaltando su aporte a una educación inclusiva y de calidad. 

    #t_2_2.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.2] Las redes del aprendizaje

    p(data-aos="fade-down") Según el enfoque del DUA, el #[b cerebro] es el órgano clave en la generación del aprendizaje, y las #[b redes neuronales] cumplen un papel fundamental en su activación y comunicación. Desde la perspectiva de la #[b neurociencia], el aprendizaje es un mecanismo biológico que surge de la #[b plasticidad sináptica], es decir, la capacidad de las neuronas para establecer conexiones eficaces con otras neuronas, fortaleciendo los #[b senderos neuronales] a través de la sinapsis.

    p(data-aos="fade-down") A continuación, se presenta una tabla comparativa con las tres redes principales del aprendizaje, según el DUA:
    .bg-full-width.bg-fondo-slider.mb-5(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Redes afectivas
              p El #[b porqué del aprendizaje]. Localizadas en el #[b lóbulo límbico]. Se relacionan con #[b emociones, valores y motivación]. Se activan cuando el aprendizaje tiene un significado personal o emocional.       
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/29.png") 
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Redes de reconocimiento
              p #[b El qué del aprendizaje]. Localizadas en la #[b parte posterior del cerebro]. Permiten el #[b reconocimiento de patrones], desde sonidos y letras, hasta conceptos complejos y abstractos. Se activan durante la búsqueda y análisis de información.       
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/30.png") 
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Redes estratégicas
              p #[b El cómo del aprendizaje]. Localizadas en los #[b lóbulos frontales]. Se encargan de las #[b funciones ejecutivas]: organización de ideas, planificación y desarrollo de acciones para alcanzar metas de aprendizaje.       
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/31.png")

    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="http://www.oas.org/juridico/spanish/tratados/a-65.html" target="_blank" rel="noopener noreferrer") ASAMBLEA GENERAL DE LA ORGANIZACIÓN DE ESTADOS AMERICANOS. (1999). Convención Interamericana para la eliminación de todas las formas de discriminación contra las personas con   discapacidad. Guatemala.  
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://unesdoc.unesco.org/ark:/48223/pf0000110753_spa 1" target="_blank" rel="noopener noreferrer") UNESCO. (1994). Conferencia Mundial Sobre Necesidades Educativas Especiales: acceso y calidad. Salamanca, España. 

            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.unicef.org/lac/dise%C3%B1o-universal-para-el-aprendizaje-y-libros-de-texto-digitales-accesibles " target="_blank" rel="noopener noreferrer") UNICEF. (s.f.). Diseño Universal para el Aprendizaje y libros de texto digitales accesibles. Conoce en qué consiste y cómo puede transformar la educación. 

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=9QI1QKmHrDg" target="_blank" rel="noopener noreferrer") CENAREC. (2021). Webinar sobre Diseño Universal para el Aprendizaje, DUA.

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema2',
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
