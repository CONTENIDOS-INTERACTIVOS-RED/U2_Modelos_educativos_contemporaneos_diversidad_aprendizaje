<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.justify-content-center.mb-5 
      .col-lg-4
        .bg-color-1.p-3.h-100.brounded.j1
          p(data-aos="fade-down").mb-0 Los procesos de inclusión en la educación, no han sido los mismos siempre. Haciendo un recorrido histórico sobre los hitos, políticas y eventos que han promovido la generación de la normatividad, se evidencia que los procesos de reflexión y cambios ha surgido en la medida en que los discursos van siendo moldeados por situaciones históricas, sociales y culturales; también ocurren cuando se generan los escenarios políticos internacionales y nacionales para defender y promover el derecho para todos.          
                
      .col-lg-4.my-4.my-lg-0
        figure
          img.img-a.img-t(src='@/assets/curso/temas/1.png', alt='', data-aos="zoom-in")          
      .col-lg-4
        .bg-color-2.h-100.brounded.j1
          .p-3
            p(data-aos="fade-down") Los discursos alrededor de la inclusión, han cambiado notoriamente a partir de los asuntos relacionados con los derechos humanos, la interculturalidad y multiculturalidad, el reconocimiento de la educación como un derecho fundamental y por supuesto, la necesidad de atender a las necesidades educativas especiales. Cuando estos temas se insertan en las agendas de gobierno, en los objetivos de desarrollo y en los programas locales, se realizan cambios sustanciales.
          .row.justify-content-end.align-items-end
            .col-auto.pb-0.px-5
              figure
                img.img-a.img-t(src='@/assets/curso/temas/2.svg', alt='', data-aos="zoom-in") 

    .bg-full-width.bg-color-3.mb-5
      .px-4.px-md-5.py-4
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/3.svg")
          .col-lg
            p.mb-0 En la presente unidad, se abordará de manera histórica, una línea de documentos nacionales e internacionales que sustentan las acciones sobre la inclusión educativa, haciendo énfasis en el caso de Colombia. Adicionalmente, se reconoce el Diseño Universal de Aprendizaje, como un método que estructura la enseñanza y la formación, desde las redes neuronales y, en coherencia con la diversidad de las personas, las condiciones y necesidades particulares; así como los propósitos o metas por alcanzar en lo educativo.                 
</template>
